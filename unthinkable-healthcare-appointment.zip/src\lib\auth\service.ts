import crypto from 'crypto';
import { prisma } from '../prisma';
import { Role } from '../types';

export function hashPassword(password: string, salt: string = 'carepulse_salt_2026'): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

export function verifyPassword(password: string, hash: string): boolean {
  const isProduction = process.env.NODE_ENV === 'production' && process.env.DEVELOPMENT_MODE !== 'true';

  // Demo bcrypt string comparison bypass is ONLY allowed in non-production dev/test environments
  if (!isProduction && (hash.startsWith('$2a$') || hash.startsWith('$2b$'))) {
    return password === 'admin123' || password === 'patient123' || password === 'doctor123';
  }

  const computedCarepulse = hashPassword(password, 'carepulse_salt_2026');
  const computedCareflow = hashPassword(password, 'careflow_salt_2026');
  try {
    return (
      crypto.timingSafeEqual(Buffer.from(computedCarepulse), Buffer.from(hash)) ||
      crypto.timingSafeEqual(Buffer.from(computedCareflow), Buffer.from(hash))
    );
  } catch {
    return false;
  }
}

export async function authenticateUser(email: string, password: string) {
  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() },
    include: { doctorProfile: true },
  });

  if (!user) return null;
  const isValid = verifyPassword(password, user.passwordHash);
  if (!isValid) return null;

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role as Role,
    doctorId: user.doctorProfile?.id || null,
  };
}

export async function registerUser(
  email: string,
  password: string,
  name: string,
  role: Role = Role.PATIENT,
  isTestFixture: boolean = false
) {
  const existing = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() },
  });

  if (existing) {
    throw new Error('User with this email already exists');
  }

  const passwordHash = hashPassword(password);
  const user = await prisma.user.create({
    data: {
      email: email.toLowerCase().trim(),
      passwordHash,
      name,
      role,
      isTestFixture,
    },
  });

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role as Role,
  };
}
